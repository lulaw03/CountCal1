﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bmi520
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>
   
        public partial class MainWindow : Window
        {
            public MainWindow()
            {
                InitializeComponent();
                // 自動調整視窗
                this.SizeToContent = SizeToContent.Manual;
            }

            private void HeightSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
            {
                if (IsInitialized)
                {
                    double heightVal = SliderChange(HeightSlider.Value, HeightNum, " cm");

                    // 位置變換
                    PositionChange(heightVal, Height, HeightC);

                    // 平均熱量
                    BMI();
                }
            }

            private void WeightSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
            {
                if (IsInitialized)
                {
                    double weightVal = SliderChange(WeightSlider.Value, WeightNum, " kg");

                    
                    PositionChange(weightVal, Weight, WeightC);

                    
                    BMI();
                }
            }

            // slider變換則數值改變
            double SliderChange(double value, TextBlock block, string unit)
            {
                double Val = Math.Round(value, 1);
                if (Val < 240)
                {
                    block.Text = Val.ToString() + unit;
                    block.Width = block.Text.Length * 10;
                }
                else
                {
                    Val = Math.Round(value, 0);
                    block.Width = 60;
                    block.Text = Val.ToString() + unit;
                }
                return Val;
            }

            // slider變換則數值改變
            void PositionChange(double changeValue, Border displayBorder, Canvas displayCanvas)
            {
                double a = ((changeValue - 50) / 200) * (displayCanvas.ActualWidth - 60);
                Canvas.SetLeft(displayBorder, a);
            }

            // 計算平均熱量
            void BMI()
            {
                
                double height = Math.Round(HeightSlider.Value, 1);
                double weight = Math.Round(WeightSlider.Value, 1);
                double year = Math.Round(YearSlider.Value, 0);
                double bmi;
                bmi = 66 + (11.7 * weight) + (3.4 * height) - (5.75 * year);

                // 顯示平均熱量結果
                string[] part = Math.Round(bmi, 2).ToString().Split('.');
                BMInum.Text = part[0];

                if (part.Length > 1)
                {
                    BMIdecimal.Text = "." + part[1];
                }
                else
                {
                    BMIdecimal.Text = ".00";
                }

                outputs.Foreground = Brushes.DimGray;
                outputs.FontWeight = FontWeights.Bold;
                outputs.FontSize = 16;
                outputs.Text = "這就是你每天所需的熱量";
              
            }

        

            // Content size changes as window changes size
            void ChangeWindowSize(object sender, SizeChangedEventArgs e)
            {
                PositionChange(SliderChange(HeightSlider.Value, HeightNum, " cm"), Height, HeightC);
                PositionChange(SliderChange(WeightSlider.Value, WeightNum, " kg"), Weight, WeightC);
            }

            private void decor_Click(object sender, RoutedEventArgs e)//outputs
            {
                HeightSlider.Value = 150;
                WeightSlider.Value = 50;
                BMInum.Text = "00";
                BMIdecimal.Text = ".00";
            }

            private void YearSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
            {

                if (IsInitialized)
                {
                    double YearVal = SliderChange(YearSlider.Value, YearNum, " age");


                    PositionChange(YearVal, Year, YearC);


                    BMI();
                }
            }
           
      }
}
    

